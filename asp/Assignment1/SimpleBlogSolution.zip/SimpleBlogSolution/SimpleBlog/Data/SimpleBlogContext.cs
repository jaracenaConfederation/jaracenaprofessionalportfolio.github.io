﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SimpleBlog.Models;

namespace SimpleBlog.Data
{
    public class SimpleBlogContext : DbContext
    {
        public SimpleBlogContext (DbContextOptions<SimpleBlogContext> options)
            : base(options)
        {
        }

        public DbSet<SimpleBlog.Models.Author> Author { get; set; }

        public DbSet<SimpleBlog.Models.Tag> Tag { get; set; }

        public DbSet<SimpleBlog.Models.Post> Post { get; set; }



    }
}
