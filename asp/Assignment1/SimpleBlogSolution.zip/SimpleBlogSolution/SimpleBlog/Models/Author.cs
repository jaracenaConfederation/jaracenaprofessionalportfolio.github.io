﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleBlog.Models
{
    public class Author
    {
        public int AuthorId { get; set; }


        [Display(Name = "Name")]
        public string AuthorName { get; set; }


        [Display(Name = "Date of birth")]
        [DataType(DataType.Date)]
        public DateTime AuthorDateBirth { get; set; }



        public List<Post> Posts { get; set; }
    }
}
