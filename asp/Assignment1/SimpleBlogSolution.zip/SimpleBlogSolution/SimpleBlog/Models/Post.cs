﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleBlog.Models
{

    public class Post
    {
        
        public int PostId { get; set; }

        public int AuthorId { get; set; }   //Foreing key
        public int TagId { get; set; }      //Foreing key


        [Required(AllowEmptyStrings=false, ErrorMessage = "You need a title")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s\.\,]*$")]
        [Display(Name ="Title")]
        
        public string PostTitle { get; set; }


        [Display(Name = "Post")]
        public string PostText { get; set; }

        [Display(Name ="Post date")]
        [DataType(DataType.Date)]
        public DateTime PostDate { get; set; }

        public Author Author { get; set; }

        public Tag Tag { get; set; }

    }
}
