﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SimpleBlog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleBlog.Pages
{
    public class IndexModel : PageModel
    {
        
        private readonly SimpleBlog.Data.SimpleBlogContext _context;

        public IndexModel(SimpleBlog.Data.SimpleBlogContext context)
        {
            _context = context;
        }

        public IList<Post> Post { get; set; }

        public async Task OnGetAsync()
        {
            Post = await _context.Post
                .Include(p => p.Author)
                .Include(p => p.Tag).OrderByDescending(p => p.PostDate).ToListAsync();
    
        }
    }
}
