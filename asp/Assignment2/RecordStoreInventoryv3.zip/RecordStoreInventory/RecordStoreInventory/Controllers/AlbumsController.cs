﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RecordStoreInventory.Data;
using RecordStoreInventory.Models;
using RecordStoreInventory.ViewModel;

namespace RecordStoreInventory.Controllers
{
    public class AlbumsController : Controller
    {
        private readonly RecordStoreInventoryContext _context;
       

        public AlbumsController(RecordStoreInventoryContext context)
        {
            _context = context;
        }

        // GET: Albums
        public async Task<IActionResult> Index()
        {
            var recordStoreInventoryContext = _context.Albums.Include(a => a.Band);
            return View(await recordStoreInventoryContext.ToListAsync());
        }

        // GET: Albums/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var album = await _context.Albums
                .Include(a => a.Band)
                .Include(b => b.AlbumGenres)            //Added
                .ThenInclude(c => c.Genre)              //Added
                .FirstOrDefaultAsync(m => m.AlbumId == id);
            if (album == null)
            {
                return NotFound();
            }

            return View(album);
        }

        // GET: Albums/Create
        public IActionResult Create()
        {
            AlbumCreateVM vm = new AlbumCreateVM
            {
                GenreSelectList = new MultiSelectList(_context.Genres, "GenreId", "GenreName")
            };
          
            ViewData["BandId"] = new SelectList(_context.Bands, "BandId", "BandName");
         
            return View(vm);
        }

        // POST: Albums/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AlbumCreateVM vm)
        {
            if (ModelState.IsValid)
            {
                Album album = new Album
                {
                    AlbumTitle = vm.AlbumTitle,
                    ReleaseDate = vm.ReleaseDate,
                    BandId = vm.BandId,

                };

                await _context.AddAsync(album);
                await _context.SaveChangesAsync();

                List<AlbumGenre> albumGenres = new List<AlbumGenre>();

                foreach (int GenreId in vm.AlbumGenreIds)
                {
                    albumGenres.Add(new AlbumGenre
                    {
                        GenreId = GenreId,
                        AlbumId = album.AlbumId
                    });
                }

                await _context.AddRangeAsync(albumGenres);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));

            }
            vm.GenreSelectList = new MultiSelectList(_context.Albums, "AlbumId", "AlbumName", vm.AlbumGenreIds);
            return View(vm);

        }

        // GET: Albums/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var album = await _context.Albums.FindAsync(id);

            //var album = await _context.Albums.FindAsync(id);
            //if (album == null)
            //{
            //    return NotFound();
            //}

            ////album.GenreSelectList = new MultiSelectList(_context.Genres, "GenreId", "GenreName");

            //ViewData["BandId"] = new SelectList(_context.Bands, "BandId", "BandName", album.BandId);

            //ViewData["GenresId"] = new SelectList(_context.Genres, "GenresId", "GenredName");
            //return View(album);

            AlbumCreateVM vm = new AlbumCreateVM
            {
                GenreSelectList = new MultiSelectList(_context.Genres, "GenreId", "GenreName")
            };

            ViewData["BandId"] = new SelectList(_context.Bands, "BandId", "BandName");

            vm.AlbumId = album.AlbumId;
            vm.AlbumTitle = album.AlbumTitle;
            vm.ReleaseDate = album.ReleaseDate;
            vm.BandId = album.BandId;
            vm.Band = album.Band;

            return View(vm);

        }

        // POST: Albums/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]

        //****************************************   NOTE ************************************************
        //
        // Commented code is old code use in the before  version of this assignment
        //
        //
        //
        //


        //public async Task<IActionResult> Edit(int id, [Bind("AlbumId,AlbumTitle,ReleaseDate,BandId")] Album album)
        //{
        //    if (id != album.AlbumId)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            //Delete of Album and Genre join from GenreAlbun table
        //            var GenreLst = new List<AlbumGenre>();

        //            var GenreQry = from m in _context.AlbumGenres
        //                           where m.AlbumId == album.AlbumId
        //                           orderby m.AlbumId
        //                           select m;
        //            GenreLst.AddRange(GenreQry.Distinct());

        //            _context.AlbumGenres.RemoveRange(GenreLst);
        //            await _context.SaveChangesAsync();


        //            _context.Update(album);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!AlbumExists(album.AlbumId))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["BandId"] = new SelectList(_context.Bands, "BandId", "BandId", album.BandId);
        //    return View(album);
        //}


        public async Task<IActionResult> Edit(int id, AlbumCreateVM vm)
        {
            if (id != vm.AlbumId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {

                try
                {


                    if (vm.AlbumGenreIds != null)
                    {
                        //Delete of Album and Genre join from GenreAlbun table
                        var GenreLst = new List<AlbumGenre>();

                        var GenreQry = from m in _context.AlbumGenres
                                       where m.AlbumId == vm.AlbumId
                                       orderby m.AlbumId
                                       select m;
                        GenreLst.AddRange(GenreQry.Distinct());

                        _context.AlbumGenres.RemoveRange(GenreLst);
                        await _context.SaveChangesAsync();
                    }

                    //Inser data to album table

                    Album album = new Album();

                    album.AlbumId = vm.AlbumId;
                    album.AlbumTitle = vm.AlbumTitle;
                    album.ReleaseDate = vm.ReleaseDate;
                    album.BandId = vm.BandId;
                    album.Band = vm.Band;

                    _context.Update(album);
                    await _context.SaveChangesAsync();

                    //Insert data os AlbumGenre table

                    List<AlbumGenre> albumGenres = new List<AlbumGenre>();

                    if (vm.AlbumGenreIds != null)
                    {

                        foreach (int GenreId in vm.AlbumGenreIds)
                        {
                            albumGenres.Add(new AlbumGenre
                            {
                                GenreId = GenreId,
                                AlbumId = album.AlbumId
                            });
                        }

                        await _context.AddRangeAsync(albumGenres);
                        await _context.SaveChangesAsync();
                    }



                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AlbumExists(vm.AlbumId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));

            }





                return View(vm);
        }

        // GET: Albums/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var album = await _context.Albums
                .Include(a => a.Band)
                .FirstOrDefaultAsync(m => m.AlbumId == id);
            if (album == null)
            {
                return NotFound();
            }

            return View(album);
        }

        // POST: Albums/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var album = await _context.Albums.FindAsync(id);
            _context.Albums.Remove(album);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AlbumExists(int id)
        {
            return _context.Albums.Any(e => e.AlbumId == id);
        }
    }
}
