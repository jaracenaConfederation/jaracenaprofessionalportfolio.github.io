﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using RecordStoreInventory.Data;
using RecordStoreInventory.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace RecordStoreInventory.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        private readonly RecordStoreInventoryContext _context;


        public HomeController(RecordStoreInventoryContext context)
        {
            _context = context;
        }

        //public IActionResult Index()
        //{



        //    return View();
        //}

        public async Task<IActionResult> Index()
        {
            var recordStoreInventoryContext = _context.Albums.Include(a => a.Band);
            return View(await recordStoreInventoryContext.ToListAsync());
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
