﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RecordStoreInventory.Models;

namespace RecordStoreInventory.Data
{
    public class RecordStoreInventoryContext : DbContext
    {
        public RecordStoreInventoryContext(DbContextOptions<RecordStoreInventoryContext> options)
            : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Band>()
                .HasKey(ba => new { ba.BandId});

            modelBuilder.Entity<Band>()
                .HasMany(p => p.Albums);

            modelBuilder.Entity<Album>()
                .HasOne(p => p.Band)
                .WithMany(pa => pa.Albums)
                .HasForeignKey(pa => pa.BandId);

            modelBuilder.Entity<AlbumGenre>()
                .HasKey(ba => new { ba.AlbumId, ba.GenreId });

            modelBuilder.Entity<AlbumGenre>()
                .HasOne(ba => ba.Album)
                .WithMany(b => b.AlbumGenres)
                .HasForeignKey(ba => ba.AlbumId);

            modelBuilder.Entity<AlbumGenre>()
                .HasOne(ba => ba.Genre)
                .WithMany(b => b.AlbumGenres)
                .HasForeignKey(ba => ba.GenreId);
        }

        public DbSet<Band> Bands { get; set; }
        public DbSet<Album> Albums { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<AlbumGenre> AlbumGenres { get; set; }
        //public object AlbumCreateVM { get; internal set; }
    }

}
