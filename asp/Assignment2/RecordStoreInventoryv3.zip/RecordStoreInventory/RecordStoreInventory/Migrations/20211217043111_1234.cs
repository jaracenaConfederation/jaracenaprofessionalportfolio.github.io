﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RecordStoreInventory.Migrations
{
    public partial class _1234 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
