﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecordStoreInventory.Models
{
    public class Band
    {
        public int BandId { get; set; }

        [Display(Name = "Band Name")]
        public string BandName { get; set; }

        [DataType(DataType.Date)]
        [Display(Name ="Date Formed")]
        public DateTime DateFormed { get; set; }


        public List<Album> Albums { get; set; }

    }

    public class Album
    {
        public int AlbumId { get; set; }

        [Display(Name = "Album Title")]
        public string AlbumTitle { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Release Date")]
        public DateTime ReleaseDate { get; set; }

        //Relationship one to one between Band and Album
        [Display(Name = "Band")]
        public int BandId { get; set; }
        public Band Band { get; set; }
        [Display(Name = "Albums's Genres")]
        public List<AlbumGenre> AlbumGenres { get; set; }


        //public MultiSelectList GenreSelectList { get; set; }

        //public List<int> AlbumGenreIds { get; set; }
    }

    public class Genre
    {
        public int GenreId { get; set; }
        [Display (Name = "Genre Name")]
        public string GenreName { get; set; }

        [Display(Name = "Albums's Genres")]
        public List<AlbumGenre> AlbumGenres { get; set; }

    }

    public class AlbumGenre
    {
        public int AlbumId { get; set; }
        public Album Album { get; set; }

        public int GenreId { get; set; }
        public Genre Genre { get; set; }

        public static implicit operator List<object>(AlbumGenre v)
        {
            throw new NotImplementedException();
        }
    }


}
