﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using RecordStoreInventory.Models;

namespace RecordStoreInventory.ViewModel
{
    public class AlbumCreateVM
    {
        public int AlbumId {get;set;}

        [Display(Name ="Album Title")]
        public string AlbumTitle { get; set; }

        public DateTime ReleaseDate { get; set; }

        public int BandId { get; set; }
        public Band Band { get; set; }

        public MultiSelectList GenreSelectList { get; set; }

        public int[] AlbumGenreIds { get; set; }

      
    }
}
