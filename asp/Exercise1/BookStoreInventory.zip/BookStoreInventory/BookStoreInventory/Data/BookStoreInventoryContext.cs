﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BookStoreInventory.Models;

namespace BookStoreInventory.Data
{
    public class BookStoreInventoryContext : DbContext
    {
        public BookStoreInventoryContext (DbContextOptions<BookStoreInventoryContext> options)
            : base(options)
        {
        }

        public DbSet<BookStoreInventory.Models.Book> Book { get; set; }

        public DbSet<BookStoreInventory.Models.Author> Author { get; set; }
    }
}
