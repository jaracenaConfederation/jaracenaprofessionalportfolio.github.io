﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BookStoreInventory.Data;
using BookStoreInventory.Models;

namespace BookStoreInventory.Pages.Authors
{
    public class IndexModel : PageModel
    {
        private readonly BookStoreInventory.Data.BookStoreInventoryContext _context;

        public IndexModel(BookStoreInventory.Data.BookStoreInventoryContext context)
        {
            _context = context;
        }

        public IList<Author> Author { get;set; }

        public async Task OnGetAsync()
        {
            Author = await _context.Author.ToListAsync();
        }
    }
}
